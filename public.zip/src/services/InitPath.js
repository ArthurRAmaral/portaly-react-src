// const dev = "/portalydev";
// export default dev;
const padrao = "/portaly";
export default padrao;
